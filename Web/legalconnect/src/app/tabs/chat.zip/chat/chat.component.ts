﻿import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { SearchService } from '../../services/search.service';

@Component({
    selector: 'chat',
    templateUrl: './chat.component.html'
})
export class ChatComponent {
    files: FileList;
    result: any;

    constructor(private srchServ: SearchService) { }
    onChange(files: FileList) {
        this.files = files;

        for (var i = 0; i < files.length; i++) {
            this.rightboxes.push({
                "url": "",
                "text": files[i].name,
                "self": true
            })
        }
    }
    rightboxes = [{
        "url": "",
        "text": "",
        "self": false
    }]
    messages = [{
        "text": "",
        "self": false,
        "time": "",
        "class":"",
    }]

    replyMessage = "";
    rightmessMessage = "";


    reply() {

        var dt = new Date();
        var time = dt.getHours() + ":" + dt.getMinutes();
        this.messages.push({
            "text": this.replyMessage,
            "self": true,
            "time": time,
            "class":"sent",
        })

        this.srchServ.getChatMessages().subscribe((res) => {
            var dt = new Date();
            var time = dt.getHours() + ":" + dt.getMinutes();
            setTimeout(() => {
                this.messages.push({
                    "text": res,
                    "self": true,
                    "time": time,
                    "class":"receive"
                })
            }, 2000);
        });

        this.srchServ.getChatReferences().subscribe((res) => {
            for (var i = 0; i < res.length; i++) {
                this.rightboxes.push({
                    "url": res[i].Url,
                    "text": res[i].Name,
                    "self": true
                })
            }
        });

        this.replyMessage = "";

    }
}